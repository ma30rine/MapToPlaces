<!DOCTYPE html>
<html>
<head>
<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	session_start();
	$nom = $bdd->query("SELECT nom FROM lieu WHERE osm_id='".$_GET['id']."';");
	$titre = $nom ->fetch();

	echo "<title>MapToPlaces : ".$titre['nom']."</title>";
 
?>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

 <script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
 <script src='ListeEtoile.js'></script>
<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />

</head>
<body>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>
<div class='main'>
	<div id = 'map'></div>
	
	<script>
		mapboxgl.accessToken = 'pk.eyJ1IjoibWFwdG9wbGFjZXMiLCJhIjoiY2oxMjU5cXVtMDA0cTMzcndxOWRjNjcxbCJ9.2eD1QePtF98GS3fFjG4HMQ';
		
		
		var geojson = {
			"id": "places",
			"type": "symbol",
			"source": {
				"type": "geojson",
				"data": {
					"type": "FeatureCollection",
					"features": [
						<?php
						
						$repo = $bdd->query("SELECT * FROM lieu WHERE osm_id='".$_GET['id']."';");
						while($rep = $repo ->fetch()){
							echo '{'."\n";
							echo '	"type": "'.$rep['categorie'].'",'."\n";
							echo '	"ident": "'.$rep['osm_id'].'",'."\n";
							echo '	"properties": {'."\n";
							echo '		"description": "<p><a href='."'lieu.php?id=".$rep['osm_id']."' target=\'_blank\' title=\'Opens in a new window\'>".$rep['nom'].'</a></p>",'."\n";
							echo '		"message": "'.$rep['nom'].'",'."\n";
							echo '		"iconSize": [32, 32]'."\n";
							echo '	},'."\n";
							echo '	"geometry": {'."\n";
							echo '		"type": "Point",'."\n";
							echo '		"coordinates": ['."\n";
							echo '			'.$rep['X'].","."\n";
							echo '			'.$rep['Y']."\n";
							echo '		]'."\n";
							echo '	}'."\n";
							echo '},'."\n";
						}
						echo '{'."\n";
						echo '	"type": "position",'."\n";
						echo '	"ident": "0",'."\n";
						echo '	"properties": {'."\n";
						echo '		"description": "<p><a href='."'lieu.php?id=".$rep['osm_id']."' target=\'_blank\' title=\'Opens in a new window\'>".$rep['nom'].'</a></p>",'."\n";
						echo '		"message": "Votre position",'."\n";
						echo '		"iconSize": [32, 32]'."\n";
						echo '	},'."\n";
						echo '	"geometry": {'."\n";
						echo '		"type": "Point",'."\n";
						echo '		"coordinates": ['."\n";
						echo '			'.$_SESSION[longitude].","."\n";
						echo '			'.$_SESSION[latitude]."\n";
						echo '		]'."\n";
						echo '	}'."\n";
						echo '},'."\n";
						?>
								
					]
				}
			}
		};
		
		var map = new mapboxgl.Map({
			container: 'map', // container id
			style: 'mapbox://styles/mapbox/streets-v9', //stylesheet location
			center: [<?php echo $_SESSION['longitude'].",".$_SESSION['latitude']; ?>], // starting position
			zoom: 17 // starting zoom
		});	
		
		geojson.source.data.features.forEach(function(marker) {
		// create a DOM element for the marker
		var el = document.createElement('div');
		el.className = 'marker';
		el.style.backgroundImage = 'url(image/'+marker.type+'_bis.png)';
		el.style.width = marker.properties.iconSize[0] + 'px';
		el.style.height = marker.properties.iconSize[1] + 'px';
		el.title = marker.properties.message;
		
		// add marker to map
		new mapboxgl.Marker(el, {offset: [-marker.properties.iconSize[0] / 2, -marker.properties.iconSize[1] / 2]})
			.setLngLat(marker.geometry.coordinates)
			.addTo(map);
		});
	
		map.addControl(new mapboxgl.GeolocateControl());
		map.addControl(new mapboxgl.NavigationControl());
 
 </script>

 
	
	<div class='bouton'>
		<?php
		
		function distance($x1, $y1, $x2, $y2){
			
			$distx = 111.132*($x1-$x2); //111.132 conversion extrêmement proche de la réalité.
			$disty = 111.320*($y1-$y2); //111.320 conversion encore plus extrêmement proche de la réalité.
			return $dis = sqrt(($distx)**2 + ($disty)**2);
		}
		
		$repo = $bdd->query("SELECT * FROM lieu WHERE osm_id='".$_GET['id']."';");
		while ($rep = $repo ->fetch()){
			echo "<div class='grande_image_lieu'>";
			echo '<a href="index.php?categorie='.$rep['categorie'].'"><img src= "image/'.$rep['categorie'].'.png" class="grande_image_cat"></a>';
			echo "</div>";
			echo "<div class='information_lieu'>";
			
			echo 'Nom: '.$rep['nom'].' </br>';
			if(isset($_SESSION['mail'])){
				echo 'Distance estimée: '.round(distance($rep['X'], $rep['Y'], $_SESSION['longitude'], $_SESSION['latitude'])*1000).'m </br>';
			}
			echo 'Type: '.$rep['type'].' </br>';
			if($rep['telephone'] != NULL){
			echo 'Téléphone: '.$rep['telephone'].'</br>';
			}
			if($rep['acces_pmr'] != NULL){
			echo 'Accès personne à mobilité réduite : '.$rep['acces_pmr'].' </br>';
			}
			if($rep['site_web'] != NULL){
			echo 'Site web: <a href="http:'.'//'.$rep['site_web'].'">'.$rep['site_web'].'</a> </br>';
			}
			if($rep['operateur'] != NULL){
			echo 'Opérateur: '.$rep['operateur'].' </br>';
			}
			if($rep['marque'] != NULL){
			echo 'Marque: '.$rep['marque'].' </br>';
			}
			if($rep['sport'] != NULL){
			echo 'Sport: '.$rep['sport'].' </br>';
			}
			if($rep['source'] != NULL){
			echo 'Source: '.$rep['source'].' </br>';
			}
			if($rep['referent'] != NULL){
			echo 'Référent: '.$rep['referent'].' </br>';
			}
			if($rep['date_mhs'] != NULL){
			echo 'Date classement monument historique: '.$rep['date_mhs'].' </br>';
			}
			if($rep['payant'] != NULL){
			echo 'Payant: '.$rep['payant'].' </br>';
			}
			if($rep['abris'] != NULL){
			echo 'Abris: '.$rep['abris'].' </br>';
			}
			if($rep['banc'] != NULL){
			echo 'Banc: '.$rep['banc'].' </br>';
			}
			echo "</div>";
		}
		
		$rep2 = $bdd->query("SELECT SUM(note) as total, COUNT(note) as nb FROM avis WHERE osm_id='".$_GET['id']."';");
		$calcul = $rep2 ->fetch();
		if($calcul['nb']!=0){
			$moyenne = $calcul['total']/$calcul['nb'];
			echo "</br><p style='font-size:40px;'>".round($moyenne,1)."/5</p>";
		}
		else{
			echo "</br><p style='font-size:40px;'>Non noté</p>";
		}
		?>
	</div>
</div>
<?php

if($_SESSION[mail]!==NULL){

	if(isset($_GET['nombreresult'])){
		$nombreresult = $_GET['nombreresult'];
	}
	else{
		$nombreresult = 3;
	}
	$repo = $bdd->query("SELECT * FROM avis, utilisateur WHERE osm_id='".$_GET['id']."' AND utilisateur.email=avis.email ORDER BY date DESC;");
	$incr = 0;
	
	while ($incr<$nombreresult && $rep = $repo ->fetch()){
		$incr=$incr+1;
		echo "<div class='lieu'>";
		echo "<div class='text_lieu'>";
		echo '<p style="font-size:20px;">Ecris par : '.$rep['nom'].' '.$rep['prenom'].'</p>';
		echo '<p style="font-size:12px; color:rgba(0,46,134,1);">le '.$rep['date'].' avec la note de '.$rep['note'].'/5 </p>';
		echo '<p style="font-size:18px; color:rgba(0,46,134,1);">'.$rep['titre']."</p>";
		echo "<p>".$rep['commentaire']."</p>";
		echo "</div></div>\n";
		}
		if($incr>=$nombreresult){
			echo "<div class='plusresultat'><a href='lieu.php?id=".$_GET['id']."&nombreresult=".((int)$nombreresult+3)."'>Afficher 3 commentaires de plus</a></div>";
		}
		else{
			echo "<div class='plusresultat'>Tout les commentaires ont été affiché.</div>";
		}
		echo "<div class='lieu'>";
		echo '<p style="font-size:20px;">Un avis sur ce lieu :</p>';

		echo "<form method='POST' action='commenter.php' autocomplete=off>";
		echo 'Titre commentaire :<INPUT type="text" name="titre" value="" cols="120"></br>';
		echo '<INPUT type="hidden" name="id" value="'.$_GET['id'].'">';
		echo 'Commentaire & note: <div id="note"><script type="text/javascript">CreateListeEtoile("note",5);</script></div></br>' ;
		echo '</br> <textarea name="commentaire" rows="3" cols="120"></textarea><br/>';
		echo '<INPUT type="hidden" name="date" value="'.date('Y-m-d').'">';		
		echo '<input type="submit" value="Envoyer">';
		echo '</form>';
}
else{
	
	echo "<div class='plusresultat'><a href='connexion.php'>Connectez-vous pour voir les avis et commentez.</a></div>";
	
}
?>


</div>	
</body>
</html>