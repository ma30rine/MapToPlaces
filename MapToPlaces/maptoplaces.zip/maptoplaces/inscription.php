<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces : Nouveau</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	
 
 
 <script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />


<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	session_start();
?>
 
 
 
 
</head>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>
 
 <div class='main'>
 
 <div id = 'map'></div>
	
	<script>
		mapboxgl.accessToken = 'pk.eyJ1IjoibWFwdG9wbGFjZXMiLCJhIjoiY2oxMjU5cXVtMDA0cTMzcndxOWRjNjcxbCJ9.2eD1QePtF98GS3fFjG4HMQ';
		
		
		var map = new mapboxgl.Map({
			container: 'map', // container id
			style: 'mapbox://styles/mapbox/streets-v9', //stylesheet location
			center: [<?php echo $_SESSION['longitude'].",".$_SESSION['latitude']; ?>], // starting position
			zoom: 12 // starting zoom
		});	
		
	
		map.addControl(new mapboxgl.GeolocateControl());
		map.addControl(new mapboxgl.NavigationControl());
 
 </script>
 
	<div class='bouton'>
	
	<h2>Inscrivez-vous :</h2>
	</br>
	<form method='POST' action='inscrire.php' autocomplete=off>
	Adresse e-mail : <INPUT type="text" name="mail" value="<?php echo $_GET['mail'] ?>"><br/><br/>
	Confirmez e-mail : <INPUT type="text" name="mail2" value=""><br/><br/>
	Mot de passe : <INPUT type="password" name="mdp" value=""><br/><br/>
	Confirmez mot de passe : <INPUT type="password" name="mdp2" value=""><br/><br/>
	Nom : <br/><INPUT type="text" name="lastname" value="<?php echo $_GET['lastname'] ?>"><br/><br/>
	Prénom : <br/><INPUT type="text" name="firstname" value="<?php echo $_GET['firstname'] ?>"><br/><br/>
	N° de téléphone : <br/><INPUT type="text" name="tel" value="<?php echo $_GET['tel'] ?>"><br/><br/>
	
	<input type="submit" value="Envoyer">
	</form>
	</div>
	
 
 
 </div>
  </body>
  </html> 