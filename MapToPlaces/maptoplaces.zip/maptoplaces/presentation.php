<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	
<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	session_start();
?>
 <style>
	
			
			#name_list {
				position: relative;
				width: 260px;
				padding-top: 0px;
				padding-bottom: 25px;
				margin: auto;
				margin-top: 5px;
				text-align: center;
				}
			.id {
				position: absolute;
				top: -250px;
				left: -500px;
				z-index: -1;
				text-align: center;
			}

			#name_list li {
				list-style-type: none;
				width: 260px;
				font-size: smaller;
				background-color: white; 
				border: 1px solid black; 
				padding: 2px;
				height : 20px;
			}
			
			#id_base {
				position: absolute;
				top: -250px;
				left: -500px;
				z-index: 0;
				text-align: center;
			}
			
			strong:hover+.id {
				z-index: +2;
			}
			
			#numl{
			height:0px;
			}
	</style>
 
 
 
</head>
<body>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>
 
 <div class='main'>
 
	<div class='bouton'>
   		<div id="centrage"><img  src="image/logo_fond_blanc.png" alt= "Page d'Accueil" height=150/></div>
		</br>
		</br>
   		<p>Cette application a été conçue par quatre étudiants de l'Université Paul Valéry 
   		de Montpellier. Pour en savoir plus, rendez-vous sur la page "Qui sommes-nous ?".</p>
   		</br>
		</br>
   		<ul id="name_list">
   			
   			<li>
   				<strong>Lisa CAUFOUR</strong>
   				<img class="id" src="image/lisa.jpg" width="270px">
   			</li>
   			<li>
   				<strong>Alexis DELAFORGE</strong>
   				<img class="id" src="image/alexis.jpg" width="270px">
   			</li>
   			<li>
   				<strong>Marine GUILHOT</strong>
   				<img class="id" src="image/marine.jpg" width="270px">
   			</li>
   			<li>
   				<strong>Jean-Baptise SIMON</strong>
   				<img class="id" src="image/jb.jpg" width="270px">
   			</li>
   			<li id="nul">
				***
   				<img id="id_base" src="image/base.jpg" width="270px">
   			</li>
   		</ul>
	</div>
	
 
 
 </div>
  </body>
  </html> 