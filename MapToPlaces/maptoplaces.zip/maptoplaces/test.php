<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces : Connexion</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	

 <script src='ListeEtoile2.js'></script>
</head>
<body>

<div id="monID"> 
<script type="text/javascript"> 
   CreateListeEtoile('monID',10); 
</script> 
</div> 

</body>