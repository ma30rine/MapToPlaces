<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces : Nouveau</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="../image/logo.gif" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	
<?php 
$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');

 
function enregistrer($nom, $prenom, $numero, $mail, $mdp)
	{
		$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');
		$requet =  "INSERT INTO `utilisateur`(`email`, `nom`, `prenom`, `telephone`, `mot_de_passe`) VALUES ('".$mail."','".$nom."','".$prenom."','".$numero."','".$mdp."')";
		$bdd->exec($requet);
	}
	
function verif($mail){
	$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');
	$ver = "SELECT COUNT(`email`) as 'bol' FROM `utilisateur` WHERE `email`='".$mail."'";
	$bool = $bdd->query($ver);
	$lol = $bool->fetch();
	if($lol['bol']!=0){
		return FALSE;
		echo "FALSE";
	}
	else{
		return TRUE;
		echo "TRUE";
	}
}

$double = FALSE;

if($_POST['mail']=="" || $_POST['mail2']=="" || $_POST['mdp']=="" || $_POST['mdp2']=="" || $_POST['lastname']=="" || $_POST['firstname']=="" || $_POST['tel']==""){
	echo '<meta http-equiv="refresh" content="1; URL=inscription.php?mail='.$_POST['mail'].'&lastname='.$_POST['lastname'].'&firstname='.$_POST['firstname'].'&tel='.$_POST['tel'].'">';
}
elseif(($_POST['mdp'] !== $_POST['mdp2']) || ($_POST['mail'] !== $_POST['mail2']) || (!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) || (!preg_match('`[0-9]{10}`',$_POST['tel']))){
	echo '<meta http-equiv="refresh" content="1; URL=inscription.php?mail='.$_POST['mail'].'&lastname='.$_POST['lastname'].'&firstname='.$_POST['firstname'].'&tel='.$_POST['tel'].'">';
}
elseif(!verif($_POST['mail'])){
	echo '<meta http-equiv="refresh" content="1; URL=inscription.php?lastname='.$_POST['lastname'].'&firstname='.$_POST['firstname'].'&tel='.$_POST['tel'].'">';
	$double = TRUE;
}
else{
	enregistrer($_POST['lastname'], $_POST['firstname'], $_POST['tel'], $_POST['mail'], $_POST['mdp']);
}
?>
</head>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>
<div class='center'>
<?php
if($_POST['mail']=="" || $_POST['mail2']=="" || $_POST['mdp']=="" || $_POST['mdp2']=="" || $_POST['lastname']=="" || $_POST['firstname']=="" || $_POST['tel']==""){
	echo "Un des champs est manquant, vous allez être redirigé vers la page d'inscription.";
}
if(!preg_match('`[0-9]{10}`',$_POST['tel'])){	
	echo "Le numéro de téléphone n'est pas valide.";
}
elseif($_POST['mdp'] !== $_POST['mdp2']){
	echo "Les mots de passes ne sont pas similaires, vous allez être redirigé vers la page d'inscription.";
}
elseif(!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) {
    echo "Votre email n'est pas valide.";
}
elseif($_POST['mail'] !== $_POST['mail2']){
	echo "Les adresses emails ne sont pas similaires, vous allez être redirigé vers la page d'inscription.";	
}
elseif($double){
	echo 'Un compte existe déjà avec cette adresse email.';
}
else{
	echo "</BR> Bonjour ".$_POST['firstname'];
	echo ", bienvenue, nous vous souhaitons une bonne visite ! Vous pouvez maintenant vous connecter.</BR>";
	echo "</BR><h2>Connectez-vous :</h2></BR>";

	echo "<form method='POST' action='connecter.php' autocomplete=off>";
	echo "Adresse e-mail :<INPUT type='text' name='mail' value=".$_GET['mail']."><br/><br/>";
	echo "Mot de passe : <INPUT type='password' name='mdp' value=".$_GET['mdp1']."><br/><br/>";
	echo "<input type='submit' value='Envoyer'>";
	echo "</form>";
	echo "</BR>";
	echo "<a href='index.php?categorie=all'><img src='image/logo_fond_blanc.png' height=258px></a>";
	echo "</BR>";
}
 ?>
</div>
</body>
</html>
