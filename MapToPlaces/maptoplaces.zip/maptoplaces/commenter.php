<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	
<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	session_start();
	
	echo '<meta http-equiv="refresh" content="1; URL=lieu.php?id='.$_POST['id'].'">';
?>
 
 
 
 
</head>
<body>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>

<?php 

$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');
$requet =  "INSERT INTO `avis`(`email`, `osm_id`, `note`, `date`, `titre`, `commentaire`) VALUES ('".$_SESSION['mail']."','".$_POST['id']."','".$_POST['note']."', '".$_POST['date']."' ,'".$_POST['titre']."','".$_POST['commentaire']."')";
$bdd->exec($requet);



?>
</br>
<div class='center'>
Votre commentaire a été enregistré, vous allez être redirigé.
</div>

</body>
</html>