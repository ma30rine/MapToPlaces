<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces : Connexion</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	
<?php 
	$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root') ;
	session_start();
?>

<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />

<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />
 
 
 
</head>
<body>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>
 
 <div class='main'>
	
	<div id = 'map'></div>
	
	<script>
		mapboxgl.accessToken = 'pk.eyJ1IjoibWFwdG9wbGFjZXMiLCJhIjoiY2oxMjU5cXVtMDA0cTMzcndxOWRjNjcxbCJ9.2eD1QePtF98GS3fFjG4HMQ';
		
		
		var map = new mapboxgl.Map({
			container: 'map', // container id
			style: 'mapbox://styles/mapbox/streets-v9', //stylesheet location
			center: [<?php echo $_SESSION['longitude'].",".$_SESSION['latitude']; ?>], // starting position
			zoom: 12 // starting zoom
		});	
		
	
		map.addControl(new mapboxgl.GeolocateControl());
		map.addControl(new mapboxgl.NavigationControl());
 
 </script>
 
	<div class='bouton'>
	</br></br></br></br></br></br></br>
	<h2>Connectez-vous :</h2>
	</br>
	<form method='POST' action='connecter.php' autocomplete=off>
	Adresse e-mail : <br/><INPUT type="text" name="mail" value="<?php echo $_GET['mail'] ?>"><br/><br/>
	Mot de passe : <br/><INPUT type="password" name="mdp" value="<?php echo $_GET['mdp1'] ?>"><br/><br/>
	<input type="submit" value="Envoyer">
	</form>
	</br>
	Montpellierain(e) sans compte ? Inscrivez vous : <a href='inscription.php'>ici</a> !
	</div>
	
 
 
 </div>
  </body>
  </html> 