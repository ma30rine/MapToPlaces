<!DOCTYPE html>
<html>
<head>
 <title>MapToPlaces : Connexion</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="shortcut icon" href="image/petit_logo.png" />
 <link rel="stylesheet"	href="style.css" type="text/css" media="screen" />	
<?php 
$bdd = new PDO('mysql:host=localhost;dbname=maptoplaces;charset=utf8', 'root', 'root');

$requet = "select * from utilisateur where email='".$_POST["mail"]."' AND mot_de_passe='".$_POST["mdp"]."'";
$rep = $bdd->query($requet);
$identifiant = $rep->fetch();

if($_POST['mail']=="" || $_POST['mdp']==""){
	echo '<meta http-equiv="refresh" content="1; URL=connexion.php?mail='.$_POST['mail'].'">';
}
elseif($identifiant[email]!=NULL){
	session_start();
	$_SESSION['nom']= $identifiant[nom];
	$_SESSION['prenom']= $identifiant[prenom];
	$_SESSION['mail']=$identifiant[email];
	echo '<meta http-equiv="refresh" content="1; URL=index.php">';
}
else{
	echo '<meta http-equiv="refresh" content="1; URL=connexion.php?mail='.$_POST['mail'].'">';
}
?>

<script src='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.js'></script>
<link href='https://api.mapbox.com/mapbox-gl-js/v0.34.0/mapbox-gl.css' rel='stylesheet' />

<script>
function geo_success(position) {
  document.location.href="index.php?lat="+position.coords.latitude+"&lon="+position.coords.longitude;
}

function geo_error() {
  alert("Sorry, no position available.");
}

var geo_options = {
  enableHighAccuracy: true, 
  maximumAge        : 30000, 
  timeout           : 27000
};

if ("geolocation" in navigator) {
  navigator.geolocation.getCurrentPosition(geo_success, geo_error, geo_options);
} else {
  /* geolocation IS NOT available */
}
</script>
</head>
<body>
<div class="bandeau_top">
<a href='index.php?categorie=all'><img src="image/logo.png" class="top_image"></a>
<ul id="menu_horizontal">
<?php

	if($_SESSION[mail]!==NULL){
		echo '<li><a href="deconnexion.php">Deconnexion</a></li>';
	}
	else{
		echo '<li><a href="connexion.php">Connexion</a></li>';
	}
?>
<li><a href="presentation.php">Présentation</a></li>
<li><a href="application.php">Application</a></li>
</ul>
<div class="session">
<?php
	if($_SESSION[mail]!==NULL){
		echo "Vous êtes actuellement connecté sous ".$_SESSION['nom']." ".$_SESSION['prenom'];
	}
	else{
		echo "Vous n'êtes pas connecté";
	}
?>
</div>
</div>
<div class='plusresultat'>
<?php
if($_POST['mail']=="" || $_POST['mdp']==""){
	echo "Un des champs est manquant, vous allez être redirigé vers la page de connexion.";
}
elseif($identifiant[email]!=NULL){
	echo "Bonjour ".$_SESSION['prenom'];
	echo ", bienvenue, nous vous souhaitons une bonne visite ! Nous vous redirigeons vers l'acceuil.";
	echo "</BR>";
}
else{
	echo "Désolé, votre email et votre mot de passe ne correspondent pas.";
}
 ?>
</div>
</body>